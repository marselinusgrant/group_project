-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2021 at 06:17 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mycar`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(4) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `booked_parts` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `customer_name`, `date`, `time`, `phone_number`, `booked_parts`) VALUES
(29, 'Bryan', '2021-06-22', '10:00:00', '01129068273', 'Rear Bumper for Sedan');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(4) NOT NULL,
  `usability` text NOT NULL,
  `quality` text NOT NULL,
  `satisfaction` int(11) NOT NULL,
  `suggestions` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `usability`, `quality`, `satisfaction`, `suggestions`) VALUES
(4, 'Excellent', 'Excellent', 10, 'I think staff should smile more :D');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(8) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(8) NOT NULL,
  `price` float NOT NULL,
  `category` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `quantity`, `price`, `category`, `image`) VALUES
(54, 'C7 Carbon Rear Bumper', 1, 6000, 'Sport', '60bb4d77e72ce.jpeg'),
(55, 'Ceramic Brakes', 4, 5000, 'Sport', '60bb4df6a5709.jpeg'),
(56, 'F8X Front Bumper', 1, 5000, 'Sport', '60bb4e342fc2a.jpeg'),
(57, 'F82 Rear Bumper', 1, 3400, 'Sport', '60bb4e57ae618.jpeg'),
(58, 'GT4 Spoiler', 1, 6000, 'Sport', '60bb4e749f4d4.jpeg'),
(59, 'GT86 Titanium Exhaust', 1, 14000, 'Sport', '60bb4e8d65338.jpeg'),
(60, 'MP Side Skirts', 2, 2500, 'Sport', '60bb4ea8d5b67.jpeg'),
(61, 'Side Mirror', 2, 3500, 'Sport', '60bb4ec3733cf.jpeg'),
(62, 'Battery Pack', 1, 6400, 'Electric', '60bb4f4505e8b.jpeg'),
(63, 'Bosch Steering', 4, 7000, 'Electric', '60bb4f64d7029.jpeg'),
(64, 'Charge Port SAE J1772', 1, 2500, 'Electric', '60bb4f7be0b5b.jpeg'),
(65, 'Coroplast High Speed Cable', 1, 200, 'Electric', '60bb4f98513f1.jpeg'),
(66, 'DC/DC Converter', 1, 2300, 'Electric', '60bb4fc80284c.jpeg'),
(67, 'ECCV EV Charging Connector', 1, 5000, 'Electric', '60bb4fe1c3183.jpeg'),
(68, 'Infineon Chip', 1, 5000, 'Electric', '60bb5003c4b30.jpeg'),
(69, 'Regenerative Brake', 1, 4000, 'Electric', '60bb502015cbf.jpeg'),
(70, 'Car Floor Mat', 2, 600, 'Sedan', '60bd75ea7a717.jpg'),
(71, 'Cargo Mat', 2, 400, 'Sedan', '60bd765da7143.jpg'),
(72, 'Ceramic Brake Pad', 1, 200, 'Sedan', '60bd76800a32d.jpg'),
(73, 'Front Bumper', 2, 500, 'Sedan', '60bd769fee08b.png'),
(74, 'Front Brake', 8, 300, 'Sedan', '60bd76c22ba25.png'),
(75, 'Headlight', 2, 2000, 'Sedan', '60bd76df32c8d.jpg'),
(76, 'Power Mirror', 3, 1000, 'Sedan', '60bd76f865ca4.jpg'),
(77, 'Rear Bumper', 1, 550, 'Sedan', '60bd770c6010c.jpg'),
(78, '252-5183 Wheel', 4, 500, 'SUV', '60bd7742afff2.jpg'),
(79, 'Exhaust Tip', 1, 500, 'SUV', '60bd77671c58b.jpg'),
(80, 'Fog Light ', 2, 300, 'SUV', '60bd7793003c8.jpg'),
(81, 'Front Brake', 2, 300, 'SUV', '60bd77ac75fa6.jpg'),
(82, 'Halogen Headlights', 1, 1700, 'SUV', '60bd77c4ea68c.jpg'),
(83, 'Hood Replacement', 1, 900, 'SUV', '60bd77dfd191c.jpg'),
(84, 'Rear Bumper Cover', 1, 1000, 'SUV', '60bd77f9f1dae.png'),
(85, 'Rhino Roof Rack', 1, 1700, 'SUV', '60bd780eb2441.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(12) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, '0340809', '$2y$10$/lj7bsm.PvGGq61.IRz43.5cU9RMhxRrjx130UeuPSgY2sjyqQJxS'),
(28, '0338062', '$2y$10$vlcf2eGgCxyv417Vu8sxeO49A1kjUYFRs5PnPgWjZBfwRqqn1pYJu'),
(29, '0340877', '$2y$10$DZM1SW127uxMO5ntFVxXDuGJIByU9XRP4VSfwHOF8SHk6CtfL0Npm'),
(30, '0340804', '$2y$10$yspEFr4.kUxSAYlCxMYAmOUG1/DpSRLaifruDqTnxUjq3B3D1lDmy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
